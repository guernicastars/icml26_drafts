# Meta-SWAG Experiments Pipeline

This directory contains standalone scripts and code to deploy the Meta-SWAG benchmark experiments on a remote multi-GPU server. It is tuned for a **4× V100-SXM2-32GB** node (Volta, sm_70, 128 GB aggregate VRAM, no native bfloat16, no FlashAttention-2) and also runs unchanged on Ampere/Hopper (A100/H100). It runs the full method suite — point-estimates (MAP, last-iterate, SWA, EMA) and Bayesian approximations (Meta-SWAG softmax/ESS/threshold, diagonal Laplace-LoRA) — for an apples-to-apples comparison.

## Hardware notes (Volta / V100)

- Auto dtype (`--dtype auto`, default everywhere) selects **fp16** on sm_70 and **bf16** on sm_80+. Hard-coded bf16 was removed from training, MMLU, axbench, and reward-model wrappers because Volta emulates bf16 in fp32 — slow and NaN-prone on long DPO trajectories.
- Reward models load in **int8 via bitsandbytes** (`--reward-int8`, default on). On V100-32GB this is required; on A100-80GB it is optional and can be disabled with `--no-reward-int8`.
- The DPO trainer uses **PEFT `disable_adapter()`** as its reference path rather than loading a second copy of the base model — saves ~16 GB during training.
- Peak alignment footprint per GPU: ~26 GB (policy 16 GB + activations + optimizer state + int8 RMs ~5 GB). Fits 32 GB V100.

## Running the pipeline

### One command (recommended)

```bash
./run_pipeline.sh
```

Runs all stages 00 → 05 in sequence. Stops immediately on the first failure and prints a summary table showing which stages passed, failed, or were skipped. All output is tee'd to `logs/pipeline_<timestamp>.log` so nothing is lost if the terminal disconnects.

```
[OK]   00  ./00_setup.sh
[OK]   01  ./01_prestage.sh
[FAIL] 02  ./02_run_alignment.sh
[SKIP] 03  ./03_run_mmlu.sh
...
```

**Useful flags:**

| Flag | Effect |
|------|--------|
| `--from 02` | Skip setup/prestage and start at a specific stage |
| `--only 02 03` | Run only the listed stages |
| `--dry-run` | Print what would run without executing anything |

```bash
./run_pipeline.sh --from 02          # resume after a completed prestage
./run_pipeline.sh --only 05          # re-collect results without re-running experiments
./run_pipeline.sh --dry-run          # sanity-check before submitting to a job scheduler
```

### Running stages manually

Each stage can also be run individually. They have been written to automatically parallelise across all 4 GPUs; per-job stdout is redirected to `logs/` and a summary prints to the terminal.

1. **`./00_setup.sh`** — creates `.venv`, installs `requirements.txt`, clones/installs Stanford AxBench, probes every GPU (compute capability, VRAM, bf16 support), and validates that `bitsandbytes` and `peft` are importable. Prints the exact line number and a clear message if any step fails.

2. **`./01_prestage.sh`** — downloads datasets and backbone checkpoints serially to prevent HuggingFace cache race conditions when parallel workers start. Gracefully skips missing sub-scripts with a warning instead of crashing silently.

3. **`./02_run_alignment.sh`** — DPO training + Meta-SWAG aggregation + best-of-n reward-overoptimisation curves.
   - Jobs = `{Llama-3.1-8B-Instruct, Gemma-2-9B-it} × {seed 42, 43, 44}` = **6 jobs in 2 waves of 4 GPUs** (external seed sharding; each Python process runs one seed).
   - Env knobs: `NUM_GPUS`, `SEEDS`, `DTYPE`, `REWARD_INT8`, `N_EPOCHS`, `POSTERIOR_SAMPLES`, `KEEP_LAST`, `MAX_TRAIN_SAMPLES`, `EXTRA_ARGS`.

4. **`./03_run_mmlu.sh`** — MMLU on the aligned adapters. For each seed under `results/alignment/<model>/seed_*/adapters/<scheme>/mean_vector.npy` the script restores the LoRA state via the saved `manifest.json` and evaluates every Meta-SWAG scheme (not just the base model).
   - Jobs = `{Llama-3.1-8B, Gemma-2-9B} × {STEM, Humanities, Social Sciences, Other}` = **8 jobs in 2 waves of 4 GPUs** (subject-group sharding). Per-group CSVs are merged into a single `mmlu_summary.csv` per model at the end.
   - Env knobs: `NUM_GPUS`, `BATCH_SIZE`, `DTYPE`, `EXTRA_ARGS`.

5. **`./04_run_axbench.sh`** — sweeps steering interventions across LLM layers using Meta-SWAG methods on AxBench concept data. Already 4-GPU parallel.

6. **`./05_collect_results.sh`** — synthesises raw metric tables into a unified summary dashboard.

## Filesystem isolation

Everything stays inside the bundle directory. No files are written outside it:

| What | Where |
|------|-------|
| Python packages | `.venv/` (created on first run, reused if exists) |
| HuggingFace model weights | `.hf_cache/hub/` |
| HuggingFace datasets | `.hf_cache/datasets/` |
| Per-job logs | `logs/` |
| All experiment outputs | `results/` |
| Master pipeline log | `logs/pipeline_<timestamp>.log` |

`HF_HOME` and `HF_DATASETS_CACHE` are set to `.hf_cache/` in every script so HuggingFace never touches `~/.cache`. If you want to override the cache location (e.g. to a shared NFS volume), set `HF_HOME` before running:

```bash
HF_HOME=/shared/hf_cache ./run_pipeline.sh
```

To wipe everything and start clean: `rm -rf .venv .hf_cache logs results`.

## Outputs and Logging

- All raw execution logs live in **`logs/`** (one log per job).
- Final artefacts persist inside **`results/`**:
  - **`results/alignment/<model>_dpo/seed_<s>/`** — retained checkpoint vectors, `manifest.json`, per-scheme adapter weights + `mean_vector.npy`, `best_of_n.csv`, `summary.csv`, `training/loss_curve.{csv,png}`.
  - **`results/mmlu/<model>/`** — `mmlu_results.csv` (per-subject), `mmlu_summary.csv` (per-scheme overall + per-group accuracies). Feeds Fig 3 bottom-row ("BMA schemes stay within 0.5pp of MAP").
  - **`results/axbench/`** — per-seed / per-concept adapter state and scheme performance reports.
  - **`results/summary.txt`** — unified dashboard from `05_collect_results.sh`.

When the run is complete, zip up `results/` and transfer it back to your local machine for analysis and paper generation.
